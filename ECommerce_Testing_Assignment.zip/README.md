# E-Commerce Testing Assignment – Ziegler Aerospace

## Tools
Java, Selenium, TestNG, Maven, POM

## Setup
Clone and run `mvn clean test`

## Author
Moraboina Narendra
